<div class="Sample">
    <h1><?php echo $this->settings['message']; ?></h1>
</div>